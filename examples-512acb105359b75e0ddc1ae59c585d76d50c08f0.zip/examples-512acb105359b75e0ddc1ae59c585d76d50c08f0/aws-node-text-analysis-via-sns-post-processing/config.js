'use strict';

module.exports = {
  awsAccountId: 'XXXXXXXXXXXX',
};
